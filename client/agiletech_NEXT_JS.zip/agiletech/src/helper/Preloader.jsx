"use client";
import { useEffect, useState } from "react";

const Preloader = () => {

  return (
    <>     
        <div className="preloader ">
          <div className="preloader-inner">
            <span className="loader"> </span>
          </div>
        </div>
    </>
  );
};

export default Preloader;
